@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.tgwsproxy.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tgwsproxy.DEFAULT_DC_IP
import com.example.tgwsproxy.ProxySettings
import com.example.tgwsproxy.newSecret

@Composable
fun SettingsScreen(
    s: ProxySettings,
    batteryIgnored: Boolean,
    running: Boolean,
    onUpdate: (ProxySettings) -> Unit,
    onCopySecret: () -> Unit,
    onBatteryFix: () -> Unit,
    onResetAll: () -> Unit,
) {
    val c = LocalAppColors.current
    val errors = s.validate()
    var showSecret by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        Spacer(Modifier.height(8.dp))
        Text("Настройки", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            if (running) "Изменения применятся после перезапуска прокси." else "Всё сохраняется автоматически.",
            color = c.muted, fontSize = 13.sp,
        )
        Spacer(Modifier.height(16.dp))

        // ------------------------------------------------------------- подключение
        AppCard {
            SectionTitle("Подключение", "Адрес и порт, на которых прокси принимает подключения Telegram.")
            Text("Кто может подключаться", color = c.muted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = s.host == "127.0.0.1",
                    onClick = { onUpdate(s.copy(host = "127.0.0.1")) },
                    label = { Text("Только этот телефон") },
                )
                FilterChip(
                    selected = s.host == "0.0.0.0",
                    onClick = { onUpdate(s.copy(host = "0.0.0.0")) },
                    label = { Text("Вся сеть") },
                )
            }
            Spacer(Modifier.height(10.dp))
            LabeledField(
                "Адрес", s.host, { onUpdate(s.copy(host = it.trim())) },
                placeholder = "127.0.0.1", error = errors["host"],
                hint = "127.0.0.1 — только это устройство. 0.0.0.0 — доступ из локальной сети (Wi‑Fi, раздача).",
            )
            Spacer(Modifier.height(12.dp))
            LabeledField(
                "Порт", s.port, { onUpdate(s.copy(port = it.filter(Char::isDigit).take(5))) },
                placeholder = "1443", error = errors["port"], number = true,
            )
            Spacer(Modifier.height(12.dp))
            LabeledField(
                "Секрет", s.secret,
                { onUpdate(s.copy(secret = it.filter { ch -> ch.isDigit() || ch.lowercaseChar() in 'a'..'f' }.take(32))) },
                placeholder = "32 hex-символа", error = errors["secret"],
                hint = "Если изменить секрет, прокси нужно заново добавить в Telegram.",
                visualTransformation = if (showSecret) VisualTransformation.None else PasswordVisualTransformation(),
                trailing = {
                    Row {
                        IconButton(onClick = { showSecret = !showSecret }) {
                            Icon(
                                if (showSecret) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                contentDescription = "Показать или скрыть секрет", tint = c.muted,
                            )
                        }
                        IconButton(onClick = { onUpdate(s.copy(secret = newSecret())) }) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Создать новый секрет", tint = c.muted)
                        }
                    }
                },
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = onCopySecret,
                shape = RoundedCornerShape(12.dp),
            ) {
                Icon(Icons.Rounded.ContentCopy, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Копировать секрет")
            }
        }
        Spacer(Modifier.height(14.dp))

        // ------------------------------------------------------------- DC
        AppCard {
            SectionTitle(
                "Серверы Telegram (DC)",
                "Для каких дата-центров Telegram прокси использует WebSocket-каналы. По одной строке: НОМЕР:IP.",
            )
            LabeledField(
                "Список DC", s.dcIp, { onUpdate(s.copy(dcIp = it)) },
                placeholder = "2:149.154.167.220", error = errors["dc"],
                singleLine = false, minLines = 3,
            )
            TextButton(onClick = { onUpdate(s.copy(dcIp = DEFAULT_DC_IP)) }) {
                Text("Вернуть по умолчанию", color = c.accent)
            }
        }
        Spacer(Modifier.height(14.dp))

        // ------------------------------------------------------------- Cloudflare
        AppCard {
            SectionTitle("Cloudflare", "Запасные пути, если прямое подключение к Telegram недоступно.")
            SwitchRow(
                "Запасной канал через Cloudflare",
                "Использовать Cloudflare-прокси, если прямой WebSocket не работает.",
                s.cfproxy,
            ) { onUpdate(s.copy(cfproxy = it)) }
            if (s.cfproxy) {
                SwitchRow(
                    "HTTP/2 для медиа",
                    "Мультиплексирование для фото и видео через Cloudflare. Обычно лучше оставить включённым.",
                    s.h2,
                ) { onUpdate(s.copy(h2 = it)) }
                Spacer(Modifier.height(8.dp))
                LabeledField(
                    "Свои Cloudflare-домены", s.cfDomains, { onUpdate(s.copy(cfDomains = it)) },
                    placeholder = "по умолчанию — автоматически",
                    hint = "Необязательно. Несколько доменов — через пробел или запятую.",
                    singleLine = false, minLines = 2,
                )
                Spacer(Modifier.height(12.dp))
                LabeledField(
                    "Cloudflare Worker-домены", s.workerDomains, { onUpdate(s.copy(workerDomains = it)) },
                    placeholder = "необязательно",
                    hint = "Домены твоих Workers. Пробуются первыми среди запасных путей.",
                    singleLine = false, minLines = 2,
                )
            }
        }
        Spacer(Modifier.height(14.dp))

        // ------------------------------------------------------------- дополнительно
        AppCard {
            SectionTitle("Дополнительно")
            LabeledField(
                "Fake TLS домен", s.fakeTlsDomain, { onUpdate(s.copy(fakeTlsDomain = it.trim())) },
                placeholder = "например example.com", error = errors["fakeTls"],
                hint = "Маскирует прокси под обычный TLS-трафик на этот домен. Ссылка для Telegram изменится.",
            )
            Spacer(Modifier.height(8.dp))
            SwitchRow(
                "Порт 80 для Cloudflare",
                "Использовать порт 80 вместо защищённого подключения к CF-прокси и Workers.",
                s.noSecure,
            ) { onUpdate(s.copy(noSecure = it)) }
            SwitchRow(
                "Тестовые дата-центры Telegram",
                "Направлять весь трафик на тестовые DC. Нужно только для разработчиков.",
                s.forceTestDc,
            ) { onUpdate(s.copy(forceTestDc = it)) }
            Spacer(Modifier.height(8.dp))
            val poolValue = (s.poolSize.toIntOrNull() ?: 4).coerceIn(0, 16)
            Text(
                "Пул WebSocket-соединений: $poolValue" + if (poolValue == 0) " (выключен)" else "",
                color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium,
            )
            Slider(
                value = poolValue.toFloat(),
                onValueChange = { onUpdate(s.copy(poolSize = it.toInt().toString())) },
                valueRange = 0f..16f,
                steps = 15,
            )
            Text(
                "Сколько готовых соединений держать для каждого DC. 0 — отключить прямой WebSocket.",
                color = c.muted, fontSize = 12.sp, lineHeight = 17.sp,
            )
            if (errors["pool"] != null) Text(errors["pool"] ?: "", color = c.danger, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            LabeledField(
                "Размер буфера, КБ", s.bufKb, { onUpdate(s.copy(bufKb = it.filter(Char::isDigit).take(4))) },
                placeholder = "256", error = errors["buf"], number = true,
            )
            Spacer(Modifier.height(8.dp))
            SwitchRow(
                "Подробный журнал",
                "Включает отладочные сообщения. Полезно для поиска проблем, но журнал становится длиннее.",
                s.verbose,
            ) { onUpdate(s.copy(verbose = it)) }
        }
        Spacer(Modifier.height(14.dp))

        // ------------------------------------------------------------- приложение
        AppCard {
            SectionTitle("Приложение")
            Text("Тема", color = c.muted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("dark" to "Тёмная", "light" to "Светлая", "system" to "Системная").forEach { (key, label) ->
                    FilterChip(
                        selected = s.theme == key,
                        onClick = { onUpdate(s.copy(theme = key)) },
                        label = { Text(label) },
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            SwitchRow(
                "Не давать процессору засыпать",
                "Прокси работает стабильнее при выключенном экране, но немного больше расходует батарею.",
                s.wakeLock,
            ) { onUpdate(s.copy(wakeLock = it)) }
            SwitchRow(
                "Запускать прокси при открытии приложения",
                "Не нужно нажимать кнопку: прокси включится сам.",
                s.autoStartOnOpen,
            ) { onUpdate(s.copy(autoStartOnOpen = it)) }
            Spacer(Modifier.height(6.dp))
            Text("Работа в фоне", color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(
                if (batteryIgnored) "Ограничения батареи сняты — Android не будет останавливать прокси."
                else "Android может останавливать прокси для экономии батареи. Рекомендуем снять ограничения.",
                color = c.muted, fontSize = 12.sp, lineHeight = 17.sp,
            )
            if (!batteryIgnored) {
                Spacer(Modifier.height(6.dp))
                OutlinedButton(onClick = onBatteryFix, shape = RoundedCornerShape(12.dp)) {
                    Text("Снять ограничения")
                }
            }
        }
        Spacer(Modifier.height(14.dp))

        AppCard {
            SectionTitle("Сброс", "Вернёт все параметры к значениям по умолчанию. Секрет сохранится.")
            OutlinedButton(
                onClick = onResetAll,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("Сбросить настройки", color = c.danger)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
