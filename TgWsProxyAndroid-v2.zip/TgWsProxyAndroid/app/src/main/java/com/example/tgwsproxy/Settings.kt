package com.example.tgwsproxy

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom

const val DEFAULT_DC_IP = "2:149.154.167.220\n4:149.154.167.220"

/** Все поля-тексты хранятся строками, чтобы пользователь мог свободно стирать и вводить значение. */
data class ProxySettings(
    // Подключение
    val host: String = "127.0.0.1",
    val port: String = "1443",
    val secret: String = "",
    // Серверы Telegram
    val dcIp: String = DEFAULT_DC_IP,
    // Cloudflare
    val cfproxy: Boolean = true,
    val h2: Boolean = true,
    val cfDomains: String = "",
    val workerDomains: String = "",
    // Дополнительно
    val fakeTlsDomain: String = "",
    val noSecure: Boolean = false,
    val forceTestDc: Boolean = false,
    val poolSize: String = "4",
    val bufKb: String = "256",
    val verbose: Boolean = false,
    // Приложение
    val wakeLock: Boolean = true,
    val autoStartOnOpen: Boolean = false,
    val theme: String = "dark", // dark | light | system
    val batteryHintDismissed: Boolean = false,
) {
    /** Возвращает карту "ключ поля -> текст ошибки". Пустая карта = всё в порядке. */
    fun validate(): Map<String, String> {
        val errors = LinkedHashMap<String, String>()

        if (host.isBlank() || host.any { it.isWhitespace() }) {
            errors["host"] = "Укажи адрес без пробелов, например 127.0.0.1"
        }
        val p = port.toIntOrNull()
        if (p == null || p !in 1..65535) {
            errors["port"] = "Порт — число от 1024 до 65535"
        } else if (p < 1024) {
            errors["port"] = "Порты до 1023 на Android недоступны без root"
        }
        if (!secret.matches(Regex("[0-9a-fA-F]{32}"))) {
            errors["secret"] = "Секрет — ровно 32 символа 0-9 и a-f"
        }
        val dcRegex = Regex("""\d{1,5}:(\d{1,3}\.){3}\d{1,3}""")
        val bad = dcList().firstOrNull { !it.matches(dcRegex) }
        if (bad != null) {
            errors["dc"] = "Неверная строка «$bad». Формат: НОМЕР_DC:IP, например 2:149.154.167.220"
        }
        val tls = fakeTlsDomain.trim()
        if (tls.isNotEmpty() && !tls.matches(Regex("""([A-Za-z0-9-]+\.)+[A-Za-z]{2,}"""))) {
            errors["fakeTls"] = "Укажи домен, например example.com"
        }
        val pool = poolSize.toIntOrNull()
        if (pool == null || pool !in 0..64) errors["pool"] = "Число от 0 до 64"
        val buf = bufKb.toIntOrNull()
        if (buf == null || buf !in 4..8192) errors["buf"] = "Число от 4 до 8192 (КБ)"
        return errors
    }

    fun dcList(): List<String> =
        dcIp.split('\n', ',', ';', ' ').map { it.trim() }.filter { it.isNotEmpty() }

    /** JSON для Python-движка. Только параметры, влияющие на сам прокси. */
    fun toEngineJson(): String {
        val o = JSONObject()
        o.put("host", host.trim())
        o.put("port", port.toIntOrNull() ?: 1443)
        o.put("secret", secret.trim().lowercase())
        o.put("dc_ip", JSONArray(dcList()))
        o.put("buf_kb", bufKb.toIntOrNull() ?: 256)
        o.put("pool_size", poolSize.toIntOrNull() ?: 4)
        o.put("cfproxy", cfproxy)
        o.put("h2", h2)
        o.put("cfproxy_domains", cfDomains)
        o.put("cfproxy_worker_domains", workerDomains)
        o.put("no_secure", noSecure)
        o.put("fake_tls_domain", fakeTlsDomain.trim())
        o.put("force_test_dc", forceTestDc)
        o.put("verbose", verbose)
        return o.toString()
    }
}

fun newSecret(): String {
    val bytes = ByteArray(16)
    SecureRandom().nextBytes(bytes)
    return bytes.joinToString("") { "%02x".format(it) }
}

object Store {
    private lateinit var prefs: SharedPreferences
    /** Compose-состояние: чтение синхронно, поэтому текстовые поля не теряют символы. */
    var settings by mutableStateOf(ProxySettings())
        private set

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences("proxy_v2", Context.MODE_PRIVATE)
        val d = ProxySettings()
        var s = ProxySettings(
            host = prefs.getString("host", d.host) ?: d.host,
            port = prefs.getString("port", d.port) ?: d.port,
            secret = prefs.getString("secret", "") ?: "",
            dcIp = prefs.getString("dcIp", d.dcIp) ?: d.dcIp,
            cfproxy = prefs.getBoolean("cfproxy", d.cfproxy),
            h2 = prefs.getBoolean("h2", d.h2),
            cfDomains = prefs.getString("cfDomains", "") ?: "",
            workerDomains = prefs.getString("workerDomains", "") ?: "",
            fakeTlsDomain = prefs.getString("fakeTlsDomain", "") ?: "",
            noSecure = prefs.getBoolean("noSecure", d.noSecure),
            forceTestDc = prefs.getBoolean("forceTestDc", d.forceTestDc),
            poolSize = prefs.getString("poolSize", d.poolSize) ?: d.poolSize,
            bufKb = prefs.getString("bufKb", d.bufKb) ?: d.bufKb,
            verbose = prefs.getBoolean("verbose", d.verbose),
            wakeLock = prefs.getBoolean("wakeLock", d.wakeLock),
            autoStartOnOpen = prefs.getBoolean("autoStartOnOpen", d.autoStartOnOpen),
            theme = prefs.getString("theme", d.theme) ?: d.theme,
            batteryHintDismissed = prefs.getBoolean("batteryHintDismissed", d.batteryHintDismissed),
        )
        if (s.secret.isBlank()) s = s.copy(secret = newSecret())
        settings = s
        save(s)
    }

    fun update(block: (ProxySettings) -> ProxySettings) {
        val n = block(settings)
        settings = n
        save(n)
    }

    private fun save(s: ProxySettings) {
        prefs.edit()
            .putString("host", s.host)
            .putString("port", s.port)
            .putString("secret", s.secret)
            .putString("dcIp", s.dcIp)
            .putBoolean("cfproxy", s.cfproxy)
            .putBoolean("h2", s.h2)
            .putString("cfDomains", s.cfDomains)
            .putString("workerDomains", s.workerDomains)
            .putString("fakeTlsDomain", s.fakeTlsDomain)
            .putBoolean("noSecure", s.noSecure)
            .putBoolean("forceTestDc", s.forceTestDc)
            .putString("poolSize", s.poolSize)
            .putString("bufKb", s.bufKb)
            .putBoolean("verbose", s.verbose)
            .putBoolean("wakeLock", s.wakeLock)
            .putBoolean("autoStartOnOpen", s.autoStartOnOpen)
            .putString("theme", s.theme)
            .putBoolean("batteryHintDismissed", s.batteryHintDismissed)
            .apply()
    }
}
