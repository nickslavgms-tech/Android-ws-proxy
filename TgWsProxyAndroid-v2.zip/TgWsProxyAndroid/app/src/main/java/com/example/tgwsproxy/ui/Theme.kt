package com.example.tgwsproxy.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
class AppColors(
    val isDark: Boolean,
    val bg: Color,
    val bgTop: Color,
    val card: Color,
    val field: Color,
    val stroke: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val accent2: Color,
    val ok: Color,
    val ok2: Color,
    val warn: Color,
    val danger: Color,
)

val DarkColors = AppColors(
    isDark = true,
    bg = Color(0xFF0B1020),
    bgTop = Color(0xFF141C38),
    card = Color(0xFF151D32),
    field = Color(0xFF10182B),
    stroke = Color(0xFF263250),
    text = Color(0xFFF1F4FF),
    muted = Color(0xFF9AA8C7),
    accent = Color(0xFF7C6CFF),
    accent2 = Color(0xFF4DA3FF),
    ok = Color(0xFF2FD39A),
    ok2 = Color(0xFF1FA7C9),
    warn = Color(0xFFFFB454),
    danger = Color(0xFFFF6B86),
)

val LightColors = AppColors(
    isDark = false,
    bg = Color(0xFFF2F4FB),
    bgTop = Color(0xFFE4E8FA),
    card = Color(0xFFFFFFFF),
    field = Color(0xFFF5F7FD),
    stroke = Color(0xFFD7DCEF),
    text = Color(0xFF141A2E),
    muted = Color(0xFF5E6A88),
    accent = Color(0xFF6552F5),
    accent2 = Color(0xFF2F8BEF),
    ok = Color(0xFF14B880),
    ok2 = Color(0xFF0C93B5),
    warn = Color(0xFFD98A12),
    danger = Color(0xFFD93A5A),
)

val LocalAppColors = staticCompositionLocalOf { DarkColors }

@Composable
fun AppTheme(dark: Boolean, content: @Composable () -> Unit) {
    val c = if (dark) DarkColors else LightColors
    val scheme = if (dark) {
        darkColorScheme(
            primary = c.accent, onPrimary = Color.White,
            background = c.bg, onBackground = c.text,
            surface = c.card, onSurface = c.text,
            surfaceVariant = c.field, onSurfaceVariant = c.muted,
            outline = c.stroke, outlineVariant = c.stroke,
            secondaryContainer = c.accent.copy(alpha = 0.22f), onSecondaryContainer = c.text,
            error = c.danger,
        )
    } else {
        lightColorScheme(
            primary = c.accent, onPrimary = Color.White,
            background = c.bg, onBackground = c.text,
            surface = c.card, onSurface = c.text,
            surfaceVariant = c.field, onSurfaceVariant = c.muted,
            outline = c.stroke, outlineVariant = c.stroke,
            secondaryContainer = c.accent.copy(alpha = 0.16f), onSecondaryContainer = c.text,
            error = c.danger,
        )
    }
    CompositionLocalProvider(LocalAppColors provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
