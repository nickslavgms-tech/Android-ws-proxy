package com.example.tgwsproxy

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.io.File

private val Bg = Color(0xFF0B1020)
private val Card = Color(0xFF151D32)
private val Purple = Color(0xFF8B75FF)
private val Muted = Color(0xFF9AA8C7)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { ProxyScreen(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProxyScreen(context: Context) {
    val prefs = remember { context.getSharedPreferences("proxy", Context.MODE_PRIVATE) }
    var host by remember { mutableStateOf(prefs.getString("host", "127.0.0.1") ?: "127.0.0.1") }
    var port by remember { mutableStateOf(prefs.getInt("port", 1443).toString()) }
    var secret by remember { mutableStateOf(prefs.getString("secret", "") ?: "") }
    var active by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(true) }
    var log by remember { mutableStateOf("Готов к запуску. Настрой параметры и нажми кнопку.") }

    LaunchedEffect(Unit) {
        while (true) {
            val file = File(context.filesDir, "tgwsproxy.log")
            if (file.exists()) log = file.readText().takeLast(3500)
            active = log.contains("Listening on") || log.contains("Connect:") || log.contains("Listening on   $host:$port")
            if (log.contains("ERROR:") || log.contains("APP ERROR:")) active = false
            kotlinx.coroutines.delay(1000)
        }
    }

    val parsedPort = port.toIntOrNull()
    val valid = parsedPort != null && parsedPort in 1..65535 && (secret.isBlank() || secret.trim().matches(Regex("[0-9a-fA-F]{32}")))

    Scaffold(containerColor = Bg) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).background(Brush.verticalGradient(listOf(Color(0xFF111A31), Bg))).verticalScroll(rememberScrollState()).padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).background(Purple, RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                    Text("TG", color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("TG WS Proxy", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("WebSocket bridge • Android", color = Muted, fontSize = 12.sp)
                }
                IconButton(onClick = { showSettings = !showSettings }) { Icon(Icons.Default.Settings, "Настройки", tint = Muted) }
            }
            Spacer(Modifier.height(24.dp))
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(if (active) Color(0xFF45D6A0) else Color(0xFFFFB454), RoundedCornerShape(50)))
                    Spacer(Modifier.width(8.dp))
                    Text(if (active) "Прокси запущен" else "Прокси остановлен", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                }
                Spacer(Modifier.height(7.dp))
                Text(if (active) "Локальный сервер слушает порт $port" else "Запускай и останавливай одним нажатием", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = {
                        prefs.edit().putString("host", host.trim()).putInt("port", parsedPort ?: 1443).putString("secret", secret.trim()).apply()
                        val intent = Intent(context, ProxyService::class.java)
                        if (active) { intent.action = ProxyService.ACTION_STOP; context.startService(intent); active = false }
                        else { ContextCompat.startForegroundService(context, intent); log = "Запускаю прокси…" }
                    }, enabled = valid, modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = if (active) Color(0xFFB9455B) else Purple), shape = RoundedCornerShape(16.dp)
                ) { Text(if (active) "ОСТАНОВИТЬ ПРОКСИ" else "ВКЛЮЧИТЬ ПРОКСИ", fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
            }
            if (showSettings) {
                Spacer(Modifier.height(16.dp))
                CardBox {
                    Text("Параметры подключения", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("Настройки сохраняются на устройстве", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(14.dp))
                    InputField("Локальный адрес", host, { host = it }, "127.0.0.1")
                    Spacer(Modifier.height(10.dp))
                    InputField("Порт", port, { port = it.filter(Char::isDigit).take(5) }, "1443")
                    Spacer(Modifier.height(10.dp))
                    InputField("Секрет (32 hex-символа, необязательно)", secret, { secret = it.filter { c -> c.isDigit() || c.lowercaseChar() in 'a'..'f' }.take(32) }, "создать автоматически")
                    Spacer(Modifier.height(8.dp))
                    Text("Для использования только на этом телефоне оставь адрес 127.0.0.1.", color = Muted, fontSize = 12.sp)
                    if (!valid) Text("Проверь порт и секрет: секрет должен содержать 32 шестнадцатеричных символа.", color = Color(0xFFFF8294), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Журнал работы", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("TG WS Proxy log", log))
                    }) { Icon(Icons.Default.ContentCopy, "Копировать журнал", tint = Muted) }
                }
                Text(log.ifBlank { "Здесь появятся сообщения прокси." }, color = Color(0xFFB6C4E2), fontSize = 11.sp, lineHeight = 16.sp)
            }
            Spacer(Modifier.height(18.dp))
            Text("Работает без root • активный режим поддерживается уведомлением Android", color = Muted, fontSize = 11.sp)
            Text("Сборка проекта пока требует проверки на реальном устройстве.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(22.dp)).padding(18.dp), content = content)
}

@Composable
private fun InputField(label: String, value: String, onValueChange: (String) -> Unit, placeholder: String) {
    Column {
        Text(label, color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(5.dp))
        OutlinedTextField(value = value, onValueChange = onValueChange, modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text(placeholder, color = Color(0xFF647391)) },
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF34415E), cursorColor = Purple,
                focusedContainerColor = Color(0xFF10182B), unfocusedContainerColor = Color(0xFF10182B)),
            shape = RoundedCornerShape(13.dp))
    }
}
