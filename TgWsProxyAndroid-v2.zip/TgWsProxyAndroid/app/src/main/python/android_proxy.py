"""Мост между Android-приложением (Kotlin) и движком tg-ws-proxy.

Kotlin вызывает:
    start(config_json) -> str   блокирующий вызов (запускать в отдельном потоке);
                                возвращает "" при штатной остановке или текст ошибки
    stop() -> bool
    status() -> str             JSON со статусом, ссылкой и статистикой
    get_logs(since) -> str      JSON {"next": int, "lines": [str, ...]}
"""
import asyncio
import json
import logging
import os
import threading
import time
from collections import deque

from proxy import tg_ws_proxy
from proxy.config import coerce_domain_list, parse_dc_ip_list, proxy_config
from proxy.stats import stats
from proxy.utils import DomainCensorFilter, get_link_host

_LOG_MAX = 2000

_lock = threading.Lock()
_loop = None
_stop_event = None
_stop_requested = False
_running = False
_error = ""
_started_at = 0.0

_log_lines = deque(maxlen=_LOG_MAX)
_log_seq = 0


class _BufferHandler(logging.Handler):
    def emit(self, record):
        global _log_seq
        try:
            line = self.format(record)
        except Exception:
            return
        with _lock:
            _log_seq += 1
            _log_lines.append((_log_seq, line))


def _add_log(text):
    global _log_seq
    stamp = time.strftime("%H:%M:%S")
    with _lock:
        _log_seq += 1
        _log_lines.append((_log_seq, "%s  APP    %s" % (stamp, text)))


def _setup_logging(verbose):
    root = logging.getLogger()
    for h in list(root.handlers):
        root.removeHandler(h)
    handler = _BufferHandler()
    handler.setFormatter(logging.Formatter(
        "%(asctime)s  %(levelname)-5s  %(message)s", datefmt="%H:%M:%S"))
    handler.addFilter(DomainCensorFilter())
    root.addHandler(handler)
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    for name in ("asyncio", "httpx", "httpcore", "hpack", "h2"):
        logging.getLogger(name).setLevel(logging.WARNING)


def _to_int(value, default, lo, hi):
    try:
        n = int(value)
    except (TypeError, ValueError):
        return default
    return max(lo, min(hi, n))


def _apply_config(cfg):
    """Переносит настройки из JSON в proxy_config. Бросает ValueError."""
    host = (cfg.get("host") or "127.0.0.1").strip()
    port = _to_int(cfg.get("port"), 1443, 1, 65535)

    secret = (cfg.get("secret") or "").strip().lower()
    if secret:
        if len(secret) != 32:
            raise ValueError("Секрет должен содержать ровно 32 hex-символа")
        try:
            bytes.fromhex(secret)
        except ValueError:
            raise ValueError("Секрет должен состоять только из hex-символов")
    else:
        secret = os.urandom(16).hex()

    dc_list = cfg.get("dc_ip")
    if dc_list is None:
        dc_list = ["2:149.154.167.220", "4:149.154.167.220"]
    elif isinstance(dc_list, str):
        dc_list = dc_list.replace(",", " ").replace(";", " ").split()
    dc_redirects = parse_dc_ip_list([str(x).strip() for x in dc_list if str(x).strip()])

    fake_tls = (cfg.get("fake_tls_domain") or "").strip()
    if fake_tls:
        try:
            fake_tls.encode("ascii")
        except UnicodeEncodeError:
            raise ValueError("Домен Fake TLS должен состоять из ASCII-символов")

    proxy_config.host = host
    proxy_config.port = port
    proxy_config.secret = secret
    proxy_config.dc_redirects = dc_redirects
    proxy_config.buffer_size = max(4, _to_int(cfg.get("buf_kb"), 256, 4, 8192)) * 1024
    proxy_config.pool_size = _to_int(cfg.get("pool_size"), 4, 0, 64)
    proxy_config.fallback_cfproxy = bool(cfg.get("cfproxy", True))
    proxy_config.cfproxy_user_domains = coerce_domain_list(cfg.get("cfproxy_domains") or "")
    proxy_config.cfproxy_worker_domains = coerce_domain_list(cfg.get("cfproxy_worker_domains") or "")
    proxy_config.cfproxy_h2_media = bool(cfg.get("h2", True))
    proxy_config.disable_secure = bool(cfg.get("no_secure", False))
    proxy_config.fake_tls_domain = fake_tls
    proxy_config.proxy_protocol = False
    proxy_config.force_test_dc = bool(cfg.get("force_test_dc", False))


async def _main():
    global _loop, _stop_event
    _loop = asyncio.get_running_loop()
    _stop_event = asyncio.Event()
    if _stop_requested:
        _stop_event.set()
    await tg_ws_proxy._run(_stop_event)


def start(config_json):
    """Запускает прокси и блокируется до остановки. Возвращает текст ошибки или ''."""
    global _running, _error, _started_at, _stop_requested, _loop, _stop_event
    with _lock:
        if _running:
            return "Прокси уже запущен"
        _running = True
        _error = ""
        _stop_requested = False
        _started_at = time.time()

    try:
        cfg = json.loads(config_json) if config_json else {}
        _setup_logging(bool(cfg.get("verbose", False)))
        _apply_config(cfg)
        stats.__init__()
    except Exception as exc:
        with _lock:
            _running = False
            _error = str(exc) or repr(exc)
        _add_log("Ошибка настроек: %s" % _error)
        return _error

    _add_log("Запуск прокси на %s:%d" % (proxy_config.host, proxy_config.port))
    result = ""
    try:
        asyncio.run(_main())
    except OSError as exc:
        if exc.errno in (98, 48, 10048):
            result = "Порт %d уже занят другим приложением" % proxy_config.port
        else:
            result = "Ошибка сети: %s" % exc
        logging.getLogger("tg-mtproto-proxy").error(result)
    except Exception as exc:
        result = "Сбой прокси: %r" % (exc,)
        logging.getLogger("tg-mtproto-proxy").exception(result)
    finally:
        with _lock:
            _running = False
            _error = result
            _loop = None
            _stop_event = None
    _add_log("Прокси остановлен" if not result else "Прокси остановлен с ошибкой")
    return result


def stop():
    global _stop_requested
    _stop_requested = True
    loop, ev = _loop, _stop_event
    if loop is not None and ev is not None:
        try:
            loop.call_soon_threadsafe(ev.set)
        except RuntimeError:
            pass
        return True
    return False


def _links():
    link_host = get_link_host(proxy_config.host) or "127.0.0.1"
    base = "tg://proxy?server=%s&port=%d" % (link_host, proxy_config.port)
    dd = "%s&secret=dd%s" % (base, proxy_config.secret)
    ftls = proxy_config.fake_tls_domain
    if ftls:
        ee = "%s&secret=ee%s%s" % (base, proxy_config.secret, ftls.encode("ascii").hex())
        return ee, ee, dd
    return dd, "", dd


def status():
    ready = tg_ws_proxy._server_instance is not None and _running
    link, ee, dd = _links() if _running else ("", "", "")
    data = {
        "running": _running,
        "ready": bool(ready),
        "error": _error,
        "started_at": _started_at if _running else 0,
        "host": proxy_config.host,
        "port": proxy_config.port,
        "secret": proxy_config.secret if _running else "",
        "link": link,
        "stats": {
            "total": stats.connections_total,
            "active": stats.connections_active,
            "ws": stats.connections_ws,
            "h2": stats.connections_h2,
            "cf": stats.connections_cfproxy,
            "tcp_fallback": stats.connections_tcp_fallback,
            "errors": stats.ws_errors,
            "up": stats.bytes_up,
            "down": stats.bytes_down,
        },
    }
    return json.dumps(data)


def get_logs(since):
    since = int(since)
    with _lock:
        lines = [text for seq, text in _log_lines if seq > since]
        nxt = _log_seq
    return json.dumps({"next": nxt, "lines": lines})


def clear_logs():
    with _lock:
        _log_lines.clear()
