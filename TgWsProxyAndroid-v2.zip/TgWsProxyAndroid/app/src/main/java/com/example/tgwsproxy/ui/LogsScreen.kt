@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.tgwsproxy.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LogsScreen(lines: List<String>, onCopy: () -> Unit, onClear: () -> Unit) {
    val c = LocalAppColors.current
    val state = rememberLazyListState()
    var autoScroll by remember { mutableStateOf(true) }

    LaunchedEffect(lines.size, autoScroll) {
        if (autoScroll && lines.isNotEmpty()) state.scrollToItem(lines.size - 1)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Журнал", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("${lines.size} строк", color = c.muted, fontSize = 12.sp)
            }
            IconButton(onClick = onCopy) {
                Icon(Icons.Rounded.ContentCopy, contentDescription = "Копировать журнал", tint = c.muted)
            }
            IconButton(onClick = onClear) {
                Icon(Icons.Rounded.Delete, contentDescription = "Очистить журнал", tint = c.muted)
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = autoScroll,
                onClick = { autoScroll = !autoScroll },
                label = { Text("Автопрокрутка") },
            )
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(c.card)
                .padding(12.dp),
        ) {
            if (lines.isEmpty()) {
                Text(
                    "Здесь появятся сообщения прокси после запуска.",
                    color = c.muted, fontSize = 13.sp,
                )
            } else {
                LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
                    items(lines) { line ->
                        val color = when {
                            line.contains("ERROR") -> c.danger
                            line.contains("WARN") -> c.warn
                            line.contains("APP ") -> c.accent
                            else -> c.muted
                        }
                        Text(
                            line,
                            color = color,
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(vertical = 1.5.dp),
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}
