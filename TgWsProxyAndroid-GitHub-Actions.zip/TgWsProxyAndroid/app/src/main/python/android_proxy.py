import asyncio
import logging
import os
import threading
from proxy.config import proxy_config, parse_dc_ip_list
from proxy.tg_ws_proxy import _run

_loop = None
_stop_event = None
_log_path = None

class FileLogHandler(logging.Handler):
    def emit(self, record):
        try:
            with open(_log_path, 'a', encoding='utf-8') as f:
                f.write(self.format(record) + '\n')
        except Exception:
            pass

def start_proxy(host='127.0.0.1', port=1443, secret='', log_path=''):
    global _loop, _stop_event, _log_path
    _log_path = log_path or '/data/local/tmp/tgwsproxy.log'
    os.makedirs(os.path.dirname(_log_path), exist_ok=True)
    with open(_log_path, 'w', encoding='utf-8') as f:
        f.write('Starting TG WS Proxy…\n')
    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(logging.INFO)
    h = FileLogHandler()
    h.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s', datefmt='%H:%M:%S'))
    root.addHandler(h)
    proxy_config.host = host
    proxy_config.port = int(port)
    proxy_config.secret = secret.strip() or os.urandom(16).hex()
    proxy_config.dc_redirects = parse_dc_ip_list(['2:149.154.167.220', '4:149.154.167.220'])
    proxy_config.buffer_size = 256 * 1024
    proxy_config.pool_size = 4
    proxy_config.fallback_cfproxy = True
    proxy_config.cfproxy_user_domains = []
    proxy_config.cfproxy_worker_domains = []
    proxy_config.cfproxy_h2_media = True
    proxy_config.disable_secure = False
    proxy_config.fake_tls_domain = ''
    proxy_config.proxy_protocol = False
    proxy_config.force_test_dc = False
    _loop = asyncio.new_event_loop()
    asyncio.set_event_loop(_loop)
    _stop_event = asyncio.Event()
    try:
        _loop.run_until_complete(_run(_stop_event))
    except Exception as e:
        logging.getLogger('tg-mtproto-proxy').exception('Proxy failed: %s', e)
        with open(_log_path, 'a', encoding='utf-8') as f:
            f.write('ERROR: ' + repr(e) + '\n')
        raise
    finally:
        _stop_event = None
        _loop.close()
        _loop = None

def stop_proxy():
    if _loop is not None and _stop_event is not None:
        _loop.call_soon_threadsafe(_stop_event.set)
        return True
    return False
