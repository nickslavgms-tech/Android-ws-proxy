package com.example.tgwsproxy

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject

enum class Phase { STOPPED, STARTING, RUNNING, STOPPING }

data class ProxyStats(
    val total: Long = 0,
    val active: Long = 0,
    val ws: Long = 0,
    val h2: Long = 0,
    val cf: Long = 0,
    val tcpFallback: Long = 0,
    val errors: Long = 0,
    val up: Long = 0,
    val down: Long = 0,
)

data class ProxyUi(
    val phase: Phase = Phase.STOPPED,
    val error: String = "",
    val link: String = "",
    val host: String = "",
    val port: Int = 0,
    val startedAtMs: Long = 0,
    val stats: ProxyStats = ProxyStats(),
    /** JSON настроек, с которыми запущен прокси (для подсказки «настройки изменены»). */
    val startedConfig: String = "",
)

object ProxyState {
    private val _ui = MutableStateFlow(ProxyUi())
    val ui: StateFlow<ProxyUi> = _ui

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs

    @Volatile var logCursor: Long = 0
    @Volatile var restartRequested: Boolean = false

    fun begin(config: String) {
        _ui.value = ProxyUi(phase = Phase.STARTING, startedConfig = config)
    }

    fun setPhase(p: Phase) {
        _ui.value = _ui.value.copy(phase = p)
    }

    fun setError(msg: String) {
        _ui.value = _ui.value.copy(phase = Phase.STOPPED, error = msg)
    }

    fun finish(error: String) {
        _ui.value = ProxyUi(phase = Phase.STOPPED, error = error)
    }

    fun applyStatus(st: JSONObject) {
        val cur = _ui.value
        if (cur.phase == Phase.STOPPED) return
        val s = st.getJSONObject("stats")
        val stats = ProxyStats(
            total = s.optLong("total"), active = s.optLong("active"), ws = s.optLong("ws"),
            h2 = s.optLong("h2"), cf = s.optLong("cf"), tcpFallback = s.optLong("tcp_fallback"),
            errors = s.optLong("errors"), up = s.optLong("up"), down = s.optLong("down"),
        )
        val ready = st.optBoolean("ready")
        val phase = when {
            cur.phase == Phase.STOPPING -> Phase.STOPPING
            ready -> Phase.RUNNING
            else -> Phase.STARTING
        }
        _ui.value = cur.copy(
            phase = phase,
            link = st.optString("link"),
            host = st.optString("host"),
            port = st.optInt("port"),
            startedAtMs = (st.optDouble("started_at") * 1000).toLong(),
            stats = stats,
        )
    }

    fun appendLogs(lines: List<String>, next: Long) {
        logCursor = next
        if (lines.isEmpty()) return
        val merged = _logs.value + lines
        _logs.value = if (merged.size > 1500) merged.takeLast(1500) else merged
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }
}

object ProxyController {
    fun start(context: Context) = send(context, ProxyService.ACTION_START)

    fun stop(context: Context) = send(context, ProxyService.ACTION_STOP)

    fun restart(context: Context) {
        if (ProxyState.ui.value.phase == Phase.STOPPED) {
            start(context)
        } else {
            ProxyState.restartRequested = true
            stop(context)
        }
    }

    private fun send(context: Context, action: String) {
        val i = Intent(context, ProxyService::class.java).setAction(action)
        ContextCompat.startForegroundService(context, i)
    }
}

fun humanBytes(n: Long): String {
    var v = n.toDouble()
    val units = arrayOf("Б", "КБ", "МБ", "ГБ", "ТБ")
    var i = 0
    while (v >= 1024 && i < units.size - 1) {
        v /= 1024
        i++
    }
    return if (i == 0) "${v.toLong()} ${units[i]}" else String.format(java.util.Locale.US, "%.1f %s", v, units[i])
}

fun formatUptime(seconds: Long): String {
    val s = if (seconds < 0) 0 else seconds
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(java.util.Locale.US, "%02d:%02d", m, sec)
}
