package com.example.tgwsproxy

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings as SettingsIcon
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import com.example.tgwsproxy.ui.AppTheme
import com.example.tgwsproxy.ui.HomeScreen
import com.example.tgwsproxy.ui.LocalAppColors
import com.example.tgwsproxy.ui.LogsScreen
import com.example.tgwsproxy.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    /** Растёт при каждом возврате в приложение — чтобы перепроверить настройки батареи. */
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (savedInstanceState == null &&
            Store.settings.autoStartOnOpen &&
            ProxyState.ui.value.phase == Phase.STOPPED &&
            Store.settings.validate().isEmpty()
        ) {
            ProxyController.start(this)
        }

        setContent { AppRoot() }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    // ------------------------------------------------------------------ действия

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    private fun copyText(label: String, text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        toast("Скопировано")
    }

    private fun openTelegram(link: String) {
        if (link.isEmpty()) {
            toast("Ссылка ещё не готова")
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: ActivityNotFoundException) {
            copyText("Telegram proxy", link)
            toast("Telegram не найден. Ссылка скопирована")
        }
    }

    private fun shareText(text: String) {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        startActivity(Intent.createChooser(send, "Поделиться ссылкой"))
    }

    private fun batteryIgnored(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun requestBatteryFix() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName")),
            )
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: Exception) {
                toast("Открой настройки батареи для этого приложения вручную")
            }
        }
    }

    // ------------------------------------------------------------------ интерфейс

    @Composable
    private fun AppRoot() {
        val settings = Store.settings
        val ui by ProxyState.ui.collectAsState()
        val logs by ProxyState.logs.collectAsState()

        val dark = when (settings.theme) {
            "light" -> false
            "system" -> isSystemInDarkTheme()
            else -> true
        }

        LaunchedEffect(dark) {
            val style = if (dark) {
                SystemBarStyle.dark(AndroidColor.TRANSPARENT)
            } else {
                SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
            }
            enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
        }

        AppTheme(dark) {
            val c = LocalAppColors.current
            var tab by remember { mutableIntStateOf(0) }
            val tick = resumeTick
            val batteryOk = remember(tick) { batteryIgnored() }

            val settingsChanged = ui.phase != Phase.STOPPED &&
                ui.startedConfig.isNotEmpty() &&
                settings.toEngineJson() != ui.startedConfig
            val showBatteryHint = !batteryOk && !settings.batteryHintDismissed

            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(c.bgTop, c.bg)))
            ) {
                Scaffold(
                    containerColor = Color.Transparent,
                    bottomBar = {
                        NavigationBar(containerColor = c.card) {
                            val itemColors = NavigationBarItemDefaults.colors(
                                selectedIconColor = c.accent,
                                selectedTextColor = c.accent,
                                indicatorColor = c.accent.copy(alpha = 0.18f),
                                unselectedIconColor = c.muted,
                                unselectedTextColor = c.muted,
                            )
                            NavigationBarItem(
                                selected = tab == 0, onClick = { tab = 0 }, colors = itemColors,
                                icon = { Icon(Icons.Rounded.Home, contentDescription = null) },
                                label = { Text("Главная") },
                            )
                            NavigationBarItem(
                                selected = tab == 1, onClick = { tab = 1 }, colors = itemColors,
                                icon = { Icon(Icons.Rounded.SettingsIcon, contentDescription = null) },
                                label = { Text("Настройки") },
                            )
                            NavigationBarItem(
                                selected = tab == 2, onClick = { tab = 2 }, colors = itemColors,
                                icon = { Icon(Icons.Rounded.Description, contentDescription = null) },
                                label = { Text("Журнал") },
                            )
                        }
                    },
                ) { inner ->
                    Box(Modifier.padding(inner).consumeWindowInsets(inner).imePadding().fillMaxSize()) {
                        when (tab) {
                            0 -> HomeScreen(
                                ui = ui,
                                settings = settings,
                                settingsChanged = settingsChanged,
                                showBatteryHint = showBatteryHint,
                                onToggle = {
                                    if (ui.phase == Phase.STOPPED) {
                                        val errors = settings.validate()
                                        if (errors.isNotEmpty()) {
                                            toast(errors.values.first())
                                            tab = 1
                                        } else {
                                            ProxyController.start(this@MainActivity)
                                        }
                                    } else if (ui.phase == Phase.RUNNING) {
                                        ProxyController.stop(this@MainActivity)
                                    }
                                },
                                onRestart = { ProxyController.restart(this@MainActivity) },
                                onOpenTelegram = { openTelegram(ui.link) },
                                onCopyLink = { copyText("Telegram proxy", ui.link) },
                                onShareLink = { shareText(ui.link) },
                                onBatteryFix = { requestBatteryFix() },
                                onBatteryDismiss = { Store.update { it.copy(batteryHintDismissed = true) } },
                            )

                            1 -> SettingsScreen(
                                s = settings,
                                batteryIgnored = batteryOk,
                                running = ui.phase != Phase.STOPPED,
                                onUpdate = { n -> Store.update { n } },
                                onCopySecret = { copyText("Secret", settings.secret) },
                                onBatteryFix = { requestBatteryFix() },
                                onResetAll = {
                                    Store.update { ProxySettings(secret = it.secret, theme = it.theme) }
                                    toast("Настройки сброшены")
                                },
                            )

                            else -> LogsScreen(
                                lines = logs,
                                onCopy = { copyText("TG WS Proxy log", logs.joinToString("\n")) },
                                onClear = {
                                    ProxyState.clearLogs()
                                    try {
                                        if (com.chaquo.python.Python.isStarted()) {
                                            PyBridge.module(this@MainActivity).callAttr("clear_logs")
                                        }
                                    } catch (_: Throwable) {
                                    }
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}
