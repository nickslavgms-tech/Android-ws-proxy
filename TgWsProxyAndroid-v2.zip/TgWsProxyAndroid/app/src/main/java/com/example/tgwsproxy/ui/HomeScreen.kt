@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.tgwsproxy.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tgwsproxy.Phase
import com.example.tgwsproxy.ProxySettings
import com.example.tgwsproxy.ProxyUi
import com.example.tgwsproxy.formatUptime
import com.example.tgwsproxy.humanBytes
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    ui: ProxyUi,
    settings: ProxySettings,
    settingsChanged: Boolean,
    showBatteryHint: Boolean,
    onToggle: () -> Unit,
    onRestart: () -> Unit,
    onOpenTelegram: () -> Unit,
    onCopyLink: () -> Unit,
    onShareLink: () -> Unit,
    onBatteryFix: () -> Unit,
    onBatteryDismiss: () -> Unit,
) {
    val c = LocalAppColors.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    val running = ui.phase == Phase.RUNNING
    val title = when (ui.phase) {
        Phase.STOPPED -> "Выключено"
        Phase.STARTING -> "Запуск…"
        Phase.RUNNING -> "Работает"
        Phase.STOPPING -> "Остановка…"
    }
    val subtitle = when (ui.phase) {
        Phase.RUNNING -> "${ui.host}:${ui.port}"
        Phase.STOPPED -> "Нажми кнопку, чтобы включить прокси"
        else -> "Подожди пару секунд"
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(c.accent, c.accent2))),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.AutoMirrored.Rounded.Send, null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("TG WS Proxy", color = c.text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("MTProto-прокси для Telegram", color = c.muted, fontSize = 12.sp)
            }
            StatusPill(ui.phase)
        }

        Spacer(Modifier.height(20.dp))
        PowerButton(ui.phase, onToggle)
        Spacer(Modifier.height(4.dp))
        Text(title, color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = c.muted, fontSize = 14.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(22.dp))

        if (ui.error.isNotEmpty() && ui.phase == Phase.STOPPED) {
            Banner(c.danger, "Не удалось запустить", ui.error)
            Spacer(Modifier.height(14.dp))
        }

        if (settingsChanged && ui.phase != Phase.STOPPED) {
            Banner(
                c.warn, "Настройки изменены",
                "Новые параметры применятся после перезапуска прокси.",
                actionLabel = "Перезапустить", onAction = onRestart,
            )
            Spacer(Modifier.height(14.dp))
        }

        if (running) {
            AppCard {
                SectionTitle(
                    "Подключить Telegram",
                    "Нажми кнопку — Telegram откроет окно добавления прокси. Подтверди «Подключить прокси». " +
                        "Дальше Telegram сам будет пользоваться прокси, пока он включён здесь.",
                )
                Button(
                    onClick = onOpenTelegram,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = Color.White),
                ) {
                    Icon(Icons.AutoMirrored.Rounded.Send, null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Добавить в Telegram", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = onCopyLink,
                        modifier = Modifier.weight(1f).height(46.dp),
                        shape = RoundedCornerShape(14.dp),
                    ) {
                        Icon(Icons.Rounded.ContentCopy, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Копировать")
                    }
                    OutlinedButton(
                        onClick = onShareLink,
                        modifier = Modifier.weight(1f).height(46.dp),
                        shape = RoundedCornerShape(14.dp),
                    ) {
                        Icon(Icons.Rounded.Share, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Поделиться")
                    }
                }
            }
            Spacer(Modifier.height(14.dp))

            AppCard {
                SectionTitle("Статистика")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(Icons.Rounded.ArrowUpward, "Отправлено", humanBytes(ui.stats.up), c.accent2, Modifier.weight(1f))
                    StatTile(Icons.Rounded.ArrowDownward, "Получено", humanBytes(ui.stats.down), c.ok, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(null, "Активные соединения", ui.stats.active.toString(), c.text, Modifier.weight(1f))
                    StatTile(null, "Всего соединений", ui.stats.total.toString(), c.text, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                val uptime = if (ui.startedAtMs > 0) (now - ui.startedAtMs) / 1000 else 0L
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(null, "Время работы", formatUptime(uptime), c.text, Modifier.weight(1f))
                    StatTile(null, "Через WebSocket / CF", "${ui.stats.ws} / ${ui.stats.cf}", c.text, Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(14.dp))
        } else if (ui.phase == Phase.STOPPED) {
            AppCard {
                SectionTitle("Как это работает")
                Step(1, "Включи прокси большой кнопкой выше.")
                Step(2, "Нажми «Добавить в Telegram» и подтверди подключение.")
                Step(3, "Готово: Telegram работает через прокси, пока он включён.")
                Spacer(Modifier.height(10.dp))
                Text(
                    "Адрес ${settings.host}:${settings.port} • параметры меняются на вкладке «Настройки».",
                    color = c.muted, fontSize = 12.sp, lineHeight = 17.sp,
                )
            }
            Spacer(Modifier.height(14.dp))
        }

        if (showBatteryHint) {
            Banner(
                c.warn, "Чтобы прокси не засыпал",
                "Разреши приложению работать в фоне без ограничений батареи — иначе Android может остановить прокси при выключенном экране.",
                actionLabel = "Разрешить", onAction = onBatteryFix, onDismiss = onBatteryDismiss,
            )
            Spacer(Modifier.height(14.dp))
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun StatusPill(phase: Phase) {
    val c = LocalAppColors.current
    val (label, color) = when (phase) {
        Phase.RUNNING -> "Онлайн" to c.ok
        Phase.STARTING -> "Запуск" to c.warn
        Phase.STOPPING -> "Стоп" to c.warn
        Phase.STOPPED -> "Офлайн" to c.muted
    }
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.16f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StatusDot(color, 8)
        Spacer(Modifier.width(7.dp))
        Text(label, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun PowerButton(phase: Phase, onClick: () -> Unit) {
    val c = LocalAppColors.current
    val running = phase == Phase.RUNNING
    val busy = phase == Phase.STARTING || phase == Phase.STOPPING
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart),
        label = "pulseValue",
    )
    val base = if (running) c.ok else c.accent
    val brush = if (running) {
        Brush.linearGradient(listOf(c.ok, c.ok2))
    } else {
        Brush.linearGradient(listOf(c.accent, c.accent2))
    }

    Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val maxR = size.minDimension / 2f
            // мягкое свечение
            drawCircle(color = base.copy(alpha = if (running) 0.16f else 0.10f), radius = maxR * 0.78f)
            if (running) {
                for (i in 0..1) {
                    val p = (pulse + i * 0.5f) % 1f
                    drawCircle(
                        color = base.copy(alpha = (1f - p) * 0.40f),
                        radius = maxR * (0.62f + 0.38f * p),
                        style = Stroke(width = 3.dp.toPx()),
                    )
                }
            }
        }
        Box(
            Modifier
                .size(158.dp)
                .clip(CircleShape)
                .background(brush)
                .clickable(enabled = !busy, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Rounded.PowerSettingsNew,
                contentDescription = if (running) "Остановить прокси" else "Включить прокси",
                tint = Color.White,
                modifier = Modifier.size(68.dp),
            )
        }
        if (busy) {
            CircularProgressIndicator(
                modifier = Modifier.size(176.dp),
                color = Color.White.copy(alpha = 0.85f),
                strokeWidth = 3.dp,
            )
        }
    }
}

@Composable
private fun StatTile(icon: ImageVector?, label: String, value: String, valueColor: Color, modifier: Modifier) {
    val c = LocalAppColors.current
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(c.field)
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(icon, null, tint = valueColor, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
            }
            Text(label, color = c.muted, fontSize = 11.sp, maxLines = 1)
        }
        Spacer(Modifier.height(4.dp))
        Text(value, color = valueColor, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun Step(n: Int, text: String) {
    val c = LocalAppColors.current
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(26.dp).clip(CircleShape).background(c.accent.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(n.toString(), color = c.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Text(text, color = c.text, fontSize = 14.sp, lineHeight = 19.sp)
    }
}
