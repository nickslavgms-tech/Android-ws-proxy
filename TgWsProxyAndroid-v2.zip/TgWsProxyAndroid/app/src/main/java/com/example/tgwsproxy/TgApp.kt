package com.example.tgwsproxy

import android.app.Application

class TgApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
    }
}
