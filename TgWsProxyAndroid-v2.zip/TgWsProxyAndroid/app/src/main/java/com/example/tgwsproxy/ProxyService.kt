package com.example.tgwsproxy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.chaquo.python.PyObject
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject

object PyBridge {
    @Synchronized
    fun module(context: Context): PyObject {
        if (!Python.isStarted()) Python.start(AndroidPlatform(context.applicationContext))
        return Python.getInstance().getModule("android_proxy")
    }
}

class ProxyService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var worker: Thread? = null
    private var pollThread: HandlerThread? = null
    private var pollHandler: Handler? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var lastNotifText = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        enterForeground(buildNotification("Запуск…"))
        if (intent?.action == ACTION_STOP) {
            stopProxy()
            return START_NOT_STICKY
        }
        startProxy()
        return START_STICKY
    }

    // ---------------------------------------------------------------- запуск / остановка

    private fun startProxy() {
        if (worker?.isAlive == true) return

        val settings = Store.settings
        val errors = settings.validate()
        if (errors.isNotEmpty()) {
            ProxyState.setError(errors.values.first())
            shutdownService()
            return
        }

        val json = settings.toEngineJson()
        ProxyState.begin(json)
        acquireWakeLock(settings.wakeLock)
        startPolling()

        worker = Thread({
            var err = ""
            try {
                err = PyBridge.module(this).callAttr("start", json).toString()
            } catch (t: Throwable) {
                err = t.message ?: t.toString()
            }
            main.post { onWorkerFinished(err) }
        }, "tg-ws-proxy").apply {
            isDaemon = true
            start()
        }
    }

    private fun stopProxy() {
        val w = worker
        if (w == null || !w.isAlive) {
            onWorkerFinished("")
            return
        }
        ProxyState.setPhase(Phase.STOPPING)
        Thread({
            try {
                PyBridge.module(this).callAttr("stop")
            } catch (_: Throwable) {
            }
        }, "tg-ws-proxy-stop").start()
        // Страховка: если движок завис при остановке, освобождаем порт, перезапустив процесс приложения.
        main.postDelayed({
            if (w.isAlive) {
                ProxyState.finish("Остановка зависла, приложение перезапущено")
                android.os.Process.killProcess(android.os.Process.myPid())
            }
        }, 12_000)
    }

    private fun onWorkerFinished(error: String) {
        stopPolling()
        if (worker != null) pollOnce()
        releaseWakeLock()
        worker = null
        if (ProxyState.restartRequested) {
            ProxyState.restartRequested = false
            startProxy()
            return
        }
        ProxyState.finish(error)
        shutdownService()
    }

    private fun shutdownService() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------------------------------------------------------------- опрос состояния

    private fun startPolling() {
        stopPolling()
        val t = HandlerThread("tg-ws-poll").also { it.start() }
        val h = Handler(t.looper)
        pollThread = t
        pollHandler = h
        h.post(object : Runnable {
            override fun run() {
                pollOnce()
                h.postDelayed(this, 1000)
            }
        })
    }

    private fun stopPolling() {
        pollHandler?.removeCallbacksAndMessages(null)
        pollThread?.quitSafely()
        pollHandler = null
        pollThread = null
    }

    private fun pollOnce() {
        try {
            val py = PyBridge.module(this)
            val st = JSONObject(py.callAttr("status").toString())
            ProxyState.applyStatus(st)
            val lg = JSONObject(py.callAttr("get_logs", ProxyState.logCursor).toString())
            val arr = lg.getJSONArray("lines")
            val lines = ArrayList<String>(arr.length())
            for (i in 0 until arr.length()) lines.add(arr.getString(i))
            ProxyState.appendLogs(lines, lg.getLong("next"))
            updateNotification()
        } catch (_: Throwable) {
        }
    }

    // ---------------------------------------------------------------- уведомление

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL_ID, "Работа прокси", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(text: String): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getForegroundService(
            this, 1,
            Intent(this, ProxyService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TG WS Proxy")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_stat_proxy)
            .setContentIntent(openApp)
            .addAction(0, "Остановить", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun enterForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    private fun updateNotification() {
        val ui = ProxyState.ui.value
        val text = when (ui.phase) {
            Phase.RUNNING ->
                "Работает на ${ui.host}:${ui.port} • ↑ ${humanBytes(ui.stats.up)} ↓ ${humanBytes(ui.stats.down)}"
            Phase.STOPPING -> "Остановка…"
            else -> "Запуск…"
        }
        if (text == lastNotifText) return
        lastNotifText = text
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(text))
    }

    // ---------------------------------------------------------------- wake lock

    private fun acquireWakeLock(enabled: Boolean) {
        releaseWakeLock()
        if (!enabled) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tgwsproxy:proxy").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Throwable) {
        }
        wakeLock = null
    }

    override fun onDestroy() {
        stopPolling()
        releaseWakeLock()
        if (worker?.isAlive == true) {
            try {
                PyBridge.module(this).callAttr("stop")
            } catch (_: Throwable) {
            }
        }
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.tgwsproxy.START"
        const val ACTION_STOP = "com.example.tgwsproxy.STOP"
        private const val CHANNEL_ID = "tgwsproxy_v2"
        private const val NOTIFICATION_ID = 1443
    }
}
