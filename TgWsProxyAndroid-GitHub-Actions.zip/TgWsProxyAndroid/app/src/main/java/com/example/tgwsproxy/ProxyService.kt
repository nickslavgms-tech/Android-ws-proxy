package com.example.tgwsproxy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

class ProxyService : Service() {
    private val running = AtomicBoolean(false)
    private var worker: Thread? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopProxy()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (running.compareAndSet(false, true)) {
            startForeground(NOTIFICATION_ID, notification("Starting proxy…"))
            val prefs = getSharedPreferences("proxy", MODE_PRIVATE)
            val host = prefs.getString("host", "127.0.0.1") ?: "127.0.0.1"
            val port = prefs.getInt("port", 1443)
            val secret = prefs.getString("secret", "") ?: ""
            val logFile = File(filesDir, "tgwsproxy.log").absolutePath
            worker = Thread {
                try {
                    if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                    Python.getInstance().getModule("android_proxy")
                        .callAttr("start_proxy", host, port, secret, logFile)
                } catch (e: Exception) {
                    File(logFile).appendText("\nAPP ERROR: ${e.message}\n")
                } finally {
                    running.set(false)
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }.apply { name = "tg-ws-proxy"; start() }
        }
        return START_NOT_STICKY
    }

    private fun stopProxy() {
        try {
            if (Python.isStarted()) Python.getInstance().getModule("android_proxy").callAttr("stop_proxy")
        } catch (_: Exception) { }
        worker?.interrupt()
        running.set(false)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "TG WS Proxy", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(text: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("TG WS Proxy").setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done).setOngoing(true).build()
    }

    override fun onDestroy() {
        stopProxy()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.example.tgwsproxy.STOP"
        private const val CHANNEL_ID = "tgwsproxy"
        private const val NOTIFICATION_ID = 1443
    }
}
